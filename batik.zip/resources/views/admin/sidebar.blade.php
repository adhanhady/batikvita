<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
      <a href="">Batik Vita</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
      <a href="">BV</a>
    </div>
    <ul class="sidebar-menu">

      <li class="menu-header">Menu</li>
        <li><a class="nav-link" href="{{route('admin.home')}}"><i class="fas fa-fire"></i> <span>Dashboard</span></a></li>
        <li><a class="nav-link" href="{{route('barang')}}"><i class="fas fa-plus"></i> <span>Data Barang</span></a></li>
        <li><a class="nav-link" href="{{route('laporan')}}"><i class="fas fa-file"></i> <span>Laporan</span></a></li>
      </ul>

  </aside>
