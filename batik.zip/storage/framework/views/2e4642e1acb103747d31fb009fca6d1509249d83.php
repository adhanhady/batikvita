<table>
    <thead>
        <tr>
                <th> No </th>
                <th> Nama barang </th>
                <th> Jumlah </th>
                <th> Harga </th>
                <th> Penghasilan </th>
                <th> Tanggal </th>

        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($l->nama_barang); ?></td>
                <td><?php echo e($l->jumlah); ?></td>
                <td><?php echo e($l->harga); ?></td>
                <td><?php echo e($l->penghasilan); ?></td>
                <td><?php echo e($l->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\batik\resources\views/export/export-laporan.blade.php ENDPATH**/ ?>